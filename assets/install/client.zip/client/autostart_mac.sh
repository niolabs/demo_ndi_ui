#!/usr/bin/env bash

nio_location="$(which nio_run)"
$nio_location -e ~/nio/projects/dni/client/envs/mbp.env &
