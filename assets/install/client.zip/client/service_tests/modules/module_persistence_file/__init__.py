# shortcut to Persistence class
from .persistence import Persistence
